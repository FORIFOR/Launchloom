# Launch copy — drafts requiring review

## x

作った、その先まで。

Launchloomで、一度の入力から、全部そろう。
まずは操作動画をご覧ください。

https://github.com/FORIFOR/Launchloom?utm_source=x&utm_medium=social&utm_campaign=4ab4455e011644bc&utm_content=a

Media: landscape.mp4

## linkedin

作った、その先まで。

Launchloomで、一度の入力から、全部そろう。
まずは操作動画をご覧ください。

一度の入力から、全部そろう。 — 横長・縦長のMP4、動画入りLP、SNS原稿、字幕、配布用ZIPまでを一度に書き出します。
実際に動かして、収録する。 — Playwrightで自分のアプリを操作し、その画面を証拠として映像にします。
書き出す前に、直せる。 — レンダリング前に構成が止まり、見出しと字幕を直してから承認できます。

https://github.com/FORIFOR/Launchloom?utm_source=linkedin&utm_medium=social&utm_campaign=4ab4455e011644bc&utm_content=a

Media: landscape.mp4

## threads

作った、その先まで。

Launchloomで、一度の入力から、全部そろう。
まずは操作動画をご覧ください。

https://github.com/FORIFOR/Launchloom?utm_source=threads&utm_medium=social&utm_campaign=4ab4455e011644bc&utm_content=a

Media: landscape.mp4

## bluesky

作った、その先まで。

Launchloomで、一度の入力から、全部そろう。
まずは操作動画をご覧ください。

https://github.com/FORIFOR/Launchloom?utm_source=bluesky&utm_medium=social&utm_campaign=4ab4455e011644bc&utm_content=a

Media: landscape.mp4

## youtube

作った、その先まで。

Launchloomで、一度の入力から、全部そろう。
まずは操作動画をご覧ください。

https://github.com/FORIFOR/Launchloom?utm_source=youtube&utm_medium=social&utm_campaign=4ab4455e011644bc&utm_content=a

Media: portrait.mp4