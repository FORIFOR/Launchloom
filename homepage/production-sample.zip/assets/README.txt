Place prepared <scene-id>.mp4 files here. Never include credentials.
