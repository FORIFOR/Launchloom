# Production handoff / 制作引き渡し beta

This bundle is a production specification, NOT a completed video.
No provider, Codex, Claude Code, After Effects or social account has been called.

1. Review production.json and the external-data content before sharing it.
2. Generate Seedance scenes in your own provider account after checking its current
   model, schema, rights, price and limits. This bundle does not submit API jobs.
3. Put each recording/generated clip in assets/<scene-id>.mp4, already trimmed to
   at least the requested duration. No credentials or source recordings are bundled.
4. Optionally open this folder in Codex or Claude Code and give it AGENT_TASK.md.
   Agent execution is manual and may incur fees. Review every proposed code change.
5. Save existing AE work. Open a blank project, then File > Scripts > Run Script File
   and select build.jsx. This creates a basic editable timeline, not bespoke AI design.
   Missing/short footage stops the build. The .aep is never overwritten.
6. Inspect typography, framing, footage, audio and rights in AE; configure the
   render queue and export there. AE execution/render quality has NOT been verified
   on a real installation for this beta. Adobe software/license is required.
7. Review the finished video. Use the final-film importer on /production, then continue to the existing
   distribution screen. Import holds local publishing; release and approve the new
   media explicitly. Existing remotely scheduled posts are not cancelled.

日本語: 構成と制作指示の引き渡し機能です。Seedanceの自動生成、エージェントの
自動実行、AEの遠隔操作、完成動画の自動回収、SNS投稿を実行しません。完成動画は制作ボードから手動で取り込めます。
既存の録画・書き出し・配信機能と並行して使えます。制作ボードの保存は既存の
動画や承認を変更しません。新しい完成動画を公開する前に改めて内容を確認してください。
