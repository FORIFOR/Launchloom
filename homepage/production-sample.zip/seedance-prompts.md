# Seedance scene prompts — manual handoff, not API requests

## opening | 4s | 16:9
From a film to a reviewed post

製品の雰囲気を伝える映像。実際の操作映像や実装の証拠として扱わない。

