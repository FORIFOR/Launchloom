// Launchloom handoff beta. Review this file before running in After Effects.
(function () {
    var plan = {"schema_version": 1, "title": "Launchloom sample", "aspect_ratio": "16:9", "fps": 30, "scenes": [{"id": "opening", "source": "seedance", "title": "A real product, clearly presented.", "prompt": "\u88fd\u54c1\u306e\u96f0\u56f2\u6c17\u3092\u4f1d\u3048\u308b\u6620\u50cf\u3002\u5b9f\u969b\u306e\u64cd\u4f5c\u6620\u50cf\u3084\u5b9f\u88c5\u306e\u8a3c\u62e0\u3068\u3057\u3066\u6271\u308f\u306a\u3044\u3002", "seconds": 4}, {"id": "product", "source": "recording", "title": "\u5b9f\u969b\u306e\u64cd\u4f5c\u753b\u9762 / Product recording", "prompt": "\u8a31\u53ef\u306e\u3042\u308b\u64cd\u4f5c\u9332\u753b\u3092\u4f7f\u3044\u3001\u6a5f\u5bc6\u60c5\u5831\u3092\u9664\u304f\u3002", "seconds": 16}, {"id": "closing", "source": "after_effects", "title": "Launchloom sample", "prompt": "\u8aad\u307f\u3084\u3059\u3044\u6587\u5b57\u3068\u63a7\u3048\u3081\u306a\u30d5\u30a7\u30fc\u30c9\u3002", "seconds": 4}]};
    var base = new File($.fileName).parent;
    var assets = new Folder(base.fsName + "/assets");
    var projectFile = new File(base.fsName + "/launchloom-project.aep");
    if (projectFile.exists) { alert("Project already exists. Use a new handoff folder."); return; }
    var i, s, file, missing = [];
    for (i = 0; i < plan.scenes.length; i++) {
        s = plan.scenes[i];
        if (s.source !== "after_effects") {
            file = new File(assets.fsName + "/" + s.id + ".mp4");
            if (!file.exists) missing.push(s.id + ".mp4");
        }
    }
    if (missing.length) { alert("Missing footage (nothing was rendered): " + missing.join(", ")); return; }
    if (app.project && app.project.numItems > 0) {
        alert("Save your work and open a blank project first. Your project was not changed."); return;
    }
    if (!app.project) app.newProject();
    app.beginUndoGroup("Launchloom production handoff");
    try {
        var wide = plan.aspect_ratio === "16:9", w = wide ? 1920 : 1080, h = wide ? 1080 : 1920;
        var total = 0, cursor = 0, layer, footage, comp, text, td, fade, position;
        for (i = 0; i < plan.scenes.length; i++) total += plan.scenes[i].seconds;
        comp = app.project.items.addComp("Launchloom_Film", w, h, 1, total, plan.fps);
        for (i = 0; i < plan.scenes.length; i++) {
            s = plan.scenes[i];
            if (s.source === "after_effects") {
                layer = comp.layers.addSolid([0.075, 0.085, 0.08], s.id, w, h, 1, total);
            } else {
                file = new File(assets.fsName + "/" + s.id + ".mp4");
                footage = app.project.importFile(new ImportOptions(file));
                if (footage.duration + 0.001 < s.seconds) throw new Error("Footage is too short: " + s.id);
                layer = comp.layers.add(footage);
                var scale = 100 * Math.min(w / footage.width, h / footage.height);
                layer.property("ADBE Transform Group").property("ADBE Scale").setValue([scale, scale]);
            }
            layer.startTime = cursor; layer.inPoint = cursor; layer.outPoint = cursor + s.seconds;
            text = comp.layers.addBoxText([w * 0.8, h * 0.38], s.title);
            td = text.property("ADBE Text Properties").property("ADBE Text Document").value;
            td.fontSize = wide ? 64 : 58; td.fillColor = [0.98, 0.96, 0.91];
            td.justification = ParagraphJustification.CENTER_JUSTIFY;
            text.property("ADBE Text Properties").property("ADBE Text Document").setValue(td);
            position = text.property("ADBE Transform Group").property("ADBE Position");
            position.setValue([w * 0.1, h * 0.55]);
            text.inPoint = cursor; text.outPoint = cursor + s.seconds;
            fade = text.property("ADBE Transform Group").property("ADBE Opacity");
            fade.setValueAtTime(cursor, 0); fade.setValueAtTime(cursor + 0.25, 100);
            fade.setValueAtTime(cursor + s.seconds - 0.25, 100); fade.setValueAtTime(cursor + s.seconds, 0);
            cursor += s.seconds;
        }
        var renderFolder = new Folder(base.fsName + "/render");
        if (!renderFolder.exists && !renderFolder.create()) throw new Error("Could not create render folder");
        var queueItem = app.project.renderQueue.items.add(comp);
        queueItem.outputModule(1).file = new File(renderFolder.fsName + "/ae-master.mov");
        app.project.save(projectFile);
        comp.openInViewer();
        alert("Project saved with a render-queue output at render/ae-master.mov. Review all frames, fonts, audio and output settings before rendering. Nothing was published.");
    } catch (e) { alert("Build stopped; no completion claimed: " + e.toString()); }
    finally { app.endUndoGroup(); }
}());
